package org.wdl.propertyms.dao;

import org.wdl.propertyms.bean.User;

public interface UserDao {

	User findByNameAndPass(String name, String password);

	User insertValues(String signname, String signemail, String signpass);
	

}
