package org.wdl.propertyms.dao;

import java.util.List;

import org.wdl.propertyms.bean.Adduser;

public interface AdduserDao {

	Adduser insertUser(String auname, String auage, String auphone, String auaddr, String autype);

	List<Adduser> find();

	Adduser findByNameAndAddr(String auname, String auaddr);

}
