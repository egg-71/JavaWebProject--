package org.wdl.propertyms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.wdl.propertyms.bean.Additem;
import org.wdl.propertyms.bean.Search;
import org.wdl.propertyms.util.ConnectionFactory;

public class SearchDaoImpl implements SearchDao {

	@Override
	public List<Search> searchitem(String searchText) {
		//�������ݿ�
		Connection connection=ConnectionFactory.getConnection();
		try {
			//׼��SQL���
			String sql="select *from tb_fee where feename=?";
			//��ȡ��װ��
			PreparedStatement preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setString(1,searchText);
			//������վ�����ݿ⣬ʹ��mysql���ݿ�ͬ��
			//preparedStatement.executeUpdate();
			ResultSet rs=preparedStatement.executeQuery();
			List<Search> searchList=new ArrayList<>();
			while(rs.next()){
				Search searchitem=new Search();
				searchitem.setId(rs.getInt("id"));
				searchitem.setFeename(rs.getString("feename"));
				searchitem.setManager(rs.getString("manager"));
				searchitem.setPrice(rs.getFloat("price"));
				searchitem.setMore(rs.getString("more"));
				searchitem.setFeetype(rs.getString("feetype"));
				searchList.add(searchitem);
			}
			connection.close();
			return searchList;	
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
