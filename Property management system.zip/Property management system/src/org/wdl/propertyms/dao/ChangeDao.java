package org.wdl.propertyms.dao;

import org.wdl.propertyms.bean.Change;

public interface ChangeDao {

	Change findByNameAndPass(String logname, String changepass);

	Change changeCode(String logname, String changepass);

}
