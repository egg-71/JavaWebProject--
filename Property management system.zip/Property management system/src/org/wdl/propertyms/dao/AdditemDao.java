package org.wdl.propertyms.dao;

import java.util.List;

import org.wdl.propertyms.bean.Additem;

public interface AdditemDao {

	Additem inserItem(String feename, String manager, String price, String more, String feetype);

	List<Additem> find();

	Additem removeItem(Integer id);



}
