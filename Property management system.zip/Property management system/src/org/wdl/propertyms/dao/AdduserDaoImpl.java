package org.wdl.propertyms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.wdl.propertyms.bean.Additem;
import org.wdl.propertyms.bean.Adduser;
import org.wdl.propertyms.bean.User;
import org.wdl.propertyms.util.ConnectionFactory;

public class AdduserDaoImpl implements AdduserDao {

	@Override
	public Adduser insertUser(String auname, String auage, String auphone, String auaddr, String autype) {
		Connection connection=ConnectionFactory.getConnection();
		try {
			//׼��SQL���
			String sql="insert into tb_usermessage(name,age,phone,address,type) values(?,?,?,?,?)";
			//��ȡ��װ��
			PreparedStatement preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setString(1,auname);
			preparedStatement.setString(2,auage);
			preparedStatement.setString(3,auphone);
			preparedStatement.setString(4,auaddr);
			preparedStatement.setString(5,autype);
			//������վ�����ݿ⣬ʹ��mysql���ݿ�ͬ��
			preparedStatement.executeUpdate();
			System.out.println("AdduserDaoImpl is doing..");
			//ִ��SQL��䣬���ز�ѯ�Ľ����װ��ResultSet����
			//��ȡִ�к�Ľ��
			connection.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Adduser> find() {
		Connection connection=ConnectionFactory.getConnection();
		try {
			//׼��SQL���
			String sql="select *from tb_usermessage";
			//��ȡ��װ��
			PreparedStatement preparedStatement=connection.prepareStatement(sql);
			ResultSet rs=preparedStatement.executeQuery();
			List<Adduser> userList=new ArrayList<>();
			while(rs.next()){
				Adduser adduser=new Adduser();
				adduser.setId(rs.getInt("id"));
				adduser.setName(rs.getString("name"));
				adduser.setAge(rs.getInt("age"));
				adduser.setPhone(rs.getString("phone"));
				adduser.setAddress(rs.getString("address"));
				adduser.setType(rs.getString("type"));
				userList.add(adduser);
			}
			connection.close();
			return userList;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Adduser findByNameAndAddr(String auname, String auaddr) {
		// TODO Auto-generated method stub
		Connection connection=ConnectionFactory.getConnection();
		try {
			//׼��SQL���
			String sql="select *from tb_usermessage where name= ? and address=?";
			//��ȡ��װ��
			PreparedStatement preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setString(1,auname);
			preparedStatement.setString(2,auaddr);
			//ִ��SQL��䣬���ز�ѯ�Ľ����װ��ResultSet����
			ResultSet rs=preparedStatement.executeQuery();
			while(rs.next()){
				Adduser user=new Adduser();
				user.setId(rs.getInt("id"));
				user.setName(rs.getString("name"));
				user.setAge(rs.getInt("age"));
				user.setPhone(rs.getString("phone"));
				user.setAddress(rs.getString("address"));
				user.setType(rs.getString("type"));
				return user;
			}
			connection.close();
			//��ȡִ�к�Ľ��
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

}
