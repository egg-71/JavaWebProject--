package org.wdl.propertyms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.wdl.propertyms.bean.Change;
import org.wdl.propertyms.bean.User;
import org.wdl.propertyms.util.ConnectionFactory;

public class ChangeDaoImpl implements ChangeDao {

	@Override
	public Change findByNameAndPass(String logname, String changepass) {
		// TODO Auto-generated method stub
		Connection connection=ConnectionFactory.getConnection();
		try {
			//׼��SQL���
			String sql="select *from tb_user where name= ?";
			//��ȡ��װ��
			PreparedStatement preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setString(1,logname);
			//ִ��SQL��䣬���ز�ѯ�Ľ����װ��ResultSet����
			ResultSet rs=preparedStatement.executeQuery();
			while(rs.next()){
				Change user=new Change();
				user.setName(rs.getString("name"));
				user.setPassword(rs.getString("password"));
				return user;
			}
			//��ȡִ�к�Ľ��
			connection.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

	@Override
	public Change changeCode(String logname, String changepass) {
		// TODO Auto-generated method stub
		Connection connection=ConnectionFactory.getConnection();
		try {
			//׼��SQL���
			String sql="update tb_user set password=?"+"where name=?";
			//��ȡ��װ��
			PreparedStatement preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setString(1,changepass);
			preparedStatement.setString(2,logname);
			//������վ�����ݿ⣬ʹ��mysql���ݿ�ͬ��
			preparedStatement.executeUpdate();
			System.out.println("This is changeCode..");
			//ִ��SQL��䣬���ز�ѯ�Ľ����װ��ResultSet����
			//��ȡִ�к�Ľ��
			connection.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}

}
