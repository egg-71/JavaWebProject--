package org.wdl.propertyms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.wdl.propertyms.bean.User;
import org.wdl.propertyms.util.ConnectionFactory;

public class UserDaoImpl implements UserDao {

	@Override
	public User findByNameAndPass(String name, String password) {
		// TODO Auto-generated method stub
		Connection connection=ConnectionFactory.getConnection();
		try {
			//׼��SQL���
			String sql="select *from tb_user where name= ? and password=?";
			//��ȡ��װ��
			PreparedStatement preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setString(1,name);
			preparedStatement.setString(2,password);
			//ִ��SQL��䣬���ز�ѯ�Ľ����װ��ResultSet����
			ResultSet rs=preparedStatement.executeQuery();
			while(rs.next()){
				User user=new User();
				user.setId(rs.getInt("id"));
				user.setPassword(rs.getString("password"));
				user.setName(rs.getString("name"));
				user.setAge(rs.getInt("age"));
				user.setSex(rs.getString("sex"));
				user.setPhone(rs.getString("phone"));
				user.setType(rs.getString("type"));
				return user;
			}
			connection.close();
			//��ȡִ�к�Ľ��
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
	
	@Override
	public User insertValues(String signname, String signemail, String signpass){
		Connection connection=ConnectionFactory.getConnection();
		try {
			//׼��SQL���
			String sql="insert into tb_user(name,phone,password) values(?,?,?)";
			//��ȡ��װ��
			PreparedStatement preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setString(1,signname);
			preparedStatement.setString(2,signemail);
			preparedStatement.setString(3,signpass);
			//������վ�����ݿ⣬ʹ��mysql���ݿ�ͬ��
			preparedStatement.executeUpdate();
			System.out.println("nice");
			//ִ��SQL��䣬���ز�ѯ�Ľ����װ��ResultSet����
			//��ȡִ�к�Ľ��
			connection.close();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}


}
