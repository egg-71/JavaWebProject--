package org.wdl.propertyms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.wdl.propertyms.bean.Additem;
import org.wdl.propertyms.util.ConnectionFactory;

public class AdditemDaoImpl implements AdditemDao {

	@Override
	public Additem inserItem(String feename, String manager, String price, String more, String feetype) {
		Connection connection=ConnectionFactory.getConnection();
		try {
			//׼��SQL���
			String sql="insert into tb_fee(feename, manager, price, more, feetype) values(?,?,?,?,?)";
			//��ȡ��װ��
			PreparedStatement preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setString(1,feename);
			preparedStatement.setString(2,manager);
			preparedStatement.setString(3,price);
			preparedStatement.setString(4,more);
			preparedStatement.setString(5,feetype);
			//������վ�����ݿ⣬ʹ��mysql���ݿ�ͬ��
			preparedStatement.executeUpdate();
			System.out.println("nice");
			//ִ��SQL��䣬���ز�ѯ�Ľ����װ��ResultSet����
			//��ȡִ�к�Ľ��
			connection.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Additem> find() {
		Connection connection=ConnectionFactory.getConnection();
		try {
			//׼��SQL���
			String sql="select *from tb_fee";
			//��ȡ��װ��
			PreparedStatement preparedStatement=connection.prepareStatement(sql);
			ResultSet rs=preparedStatement.executeQuery();
			List<Additem> addList=new ArrayList<>();
			while(rs.next()){
				Additem additem=new Additem();
				additem.setId(rs.getInt("id"));
				additem.setFeename(rs.getString("feename"));
				additem.setManager(rs.getString("manager"));
				additem.setPrice(rs.getFloat("price"));
				additem.setMore(rs.getString("more"));
				additem.setFeetype(rs.getString("feetype"));
				addList.add(additem);
			}
			connection.close();
			return addList;
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Additem removeItem(Integer id) {
		// TODO Auto-generated method stub
		Connection connection=ConnectionFactory.getConnection();
		try {
			//׼��SQL���
			String sql="delete from tb_fee where id=?";
			//��ȡ��װ��
			PreparedStatement preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setInt(1,id);
			//������վ�����ݿ⣬ʹ��mysql���ݿ�ͬ��
			preparedStatement.executeUpdate();
			System.out.println("removeItem is ...");
			//ִ��SQL��䣬���ز�ѯ�Ľ����װ��ResultSet����
			//��ȡִ�к�Ľ��
			connection.close();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}



}
