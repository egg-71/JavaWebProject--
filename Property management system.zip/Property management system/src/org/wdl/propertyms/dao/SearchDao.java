package org.wdl.propertyms.dao;

import java.util.List;

import org.wdl.propertyms.bean.Search;

public interface SearchDao {

	List<Search> searchitem(String searchText);

}
