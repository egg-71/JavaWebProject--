package org.wdl.propertyms.bean;

public class Adduser {
	private Integer id;//�û�id
	private String name;//�û�����
	private Integer age;//����
	private String phone;//��ϵ�绰
	private String address;//סַ
	private String type;//�û����
	
	
	public Adduser(Integer id, String name, Integer age, String phone, String address, String type) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.phone = phone;
		this.address = address;
		this.type = type;
	}
	public Adduser() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Adduser [id=" + id + ", name=" + name + ", age=" + age + ", phone=" + phone + ", address=" + address
				+ ", type=" + type + "]";
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
}
