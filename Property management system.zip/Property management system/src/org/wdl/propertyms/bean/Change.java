package org.wdl.propertyms.bean;

public class Change {
	private String name;//�û���
	private String password;//����
	
	public Change() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Change(String name, String password) {
		super();
		this.name = name;
		this.password = password;
	}
	@Override
	public String toString() {
		return "Change [name=" + name + ", password=" + password + "]";
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
