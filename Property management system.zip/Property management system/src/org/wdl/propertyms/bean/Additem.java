package org.wdl.propertyms.bean;

public class Additem {
	private Integer id;//������Ŀid
	private String feename;//��������
	private String manager;//������
	private Float price;//�۸�
	private String more;//��ע
	private String feetype;//�������
	
	public Additem(Integer id, String feename, String manager, Float price, String more, String feetype) {
		super();
		this.id = id;
		this.feename = feename;
		this.manager = manager;
		this.price = price;
		this.more = more;
		this.feetype = feetype;
	}
	public Additem(){
		super();
	}
	@Override
	public String toString() {
		return "Additem [id=" + id + ", feename=" + feename + ", manager=" + manager + ", price=" + price + ", more="
				+ more + ", feetype=" + feetype + "]";
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getFeename() {
		return feename;
	}
	public void setFeename(String feename) {
		this.feename = feename;
	}
	public String getManager() {
		return manager;
	}
	public void setManager(String manager) {
		this.manager = manager;
	}
	public Float getPrice() {
		return price;
	}
	public void setPrice(Float price) {
		this.price = price;
	}
	public String getMore() {
		return more;
	}
	public void setMore(String more) {
		this.more = more;
	}
	public String getFeetype() {
		return feetype;
	}
	public void setFeetype(String feetype) {
		this.feetype = feetype;
	}
	
}
