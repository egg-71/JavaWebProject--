package org.wdl.propertyms.service;

import org.wdl.propertyms.bean.User;
import org.wdl.propertyms.dao.UserDao;
import org.wdl.propertyms.dao.UserDaoImpl;

public class UserServiceImp implements UserService {
	private UserDao userDao=new UserDaoImpl();
	@Override
	public User findByNameAndPass(String name, String password) {
		// TODO Auto-generated method stub
		return userDao.findByNameAndPass(name,password);
	}
	@Override
	public User insertValues(String signname, String signemail, String signpass) {
		// TODO Auto-generated method stub
		return userDao.insertValues(signname, signemail,signpass);
	}

}
