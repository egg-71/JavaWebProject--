package org.wdl.propertyms.service;

import org.wdl.propertyms.bean.Change;
import org.wdl.propertyms.dao.ChangeDao;
import org.wdl.propertyms.dao.ChangeDaoImpl;

public class ChangeServiceImp implements ChangeService {
	private ChangeDao changeDao=new ChangeDaoImpl();

	@Override
	public Change findByNameAndPass(String logname, String changepass) {
		// TODO Auto-generated method stub
		return changeDao.findByNameAndPass(logname, changepass);
	}

	@Override
	public Change changeCode(String logname, String changepass) {
		// TODO Auto-generated method stub
		return changeDao.changeCode(logname, changepass);
	}

}
