package org.wdl.propertyms.service;

import java.util.List;

import org.wdl.propertyms.bean.Search;

public interface SearchService {

	List<Search> searchitem(String searchText);

}
