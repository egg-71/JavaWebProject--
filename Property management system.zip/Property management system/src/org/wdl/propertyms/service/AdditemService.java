package org.wdl.propertyms.service;

import java.util.List;

import org.wdl.propertyms.bean.Additem;

public interface AdditemService {

	Additem insertItem(String feename, String manager, String price, String more, String feetype);

	List<Additem> find();

	Additem removeItem(Integer id);



}
