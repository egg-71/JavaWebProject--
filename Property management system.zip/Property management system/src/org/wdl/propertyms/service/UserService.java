package org.wdl.propertyms.service;

import org.wdl.propertyms.bean.User;

public interface UserService {

	User findByNameAndPass(String name, String password);

	User insertValues(String signname, String signemail, String signpass);



}
