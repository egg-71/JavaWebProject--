package org.wdl.propertyms.service;

import org.wdl.propertyms.bean.Change;

public interface ChangeService {

	Change findByNameAndPass(String logname, String changepass);

	Change changeCode(String logname, String changepass);

}
