package org.wdl.propertyms.service;

import java.util.List;

import org.wdl.propertyms.bean.Adduser;
import org.wdl.propertyms.dao.AdduserDao;
import org.wdl.propertyms.dao.AdduserDaoImpl;

public class AdduserServiceImp implements AdduserService {
	private AdduserDao adduserDao=new AdduserDaoImpl();
	@Override
	public Adduser insertUser(String auname, String auage, String auphone, String auaddr, String autype) {
		// TODO Auto-generated method stub
		return adduserDao.insertUser(auname,auage,auphone,auaddr,autype);
	}
	@Override
	public List<Adduser> find() {
		// TODO Auto-generated method stub
		return adduserDao.find();
	}
	@Override
	public Adduser findByNameAndAddr(String auname, String auaddr) {
		// TODO Auto-generated method stub
		return adduserDao.findByNameAndAddr(auname, auaddr);
	}

}
