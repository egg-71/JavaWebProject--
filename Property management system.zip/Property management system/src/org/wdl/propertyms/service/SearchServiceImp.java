package org.wdl.propertyms.service;

import java.util.List;

import org.wdl.propertyms.bean.Search;
import org.wdl.propertyms.dao.SearchDao;
import org.wdl.propertyms.dao.SearchDaoImpl;


public class SearchServiceImp implements SearchService {
	private SearchDao searchDao=new SearchDaoImpl();
	@Override
	public List<Search> searchitem(String searchText) {
		
		// TODO Auto-generated method stub
		return searchDao.searchitem(searchText);
	}

}
