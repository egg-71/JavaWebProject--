package org.wdl.propertyms.service;

import java.util.List;

import org.wdl.propertyms.bean.Adduser;

public interface AdduserService {

	Adduser insertUser(String auname, String auage, String auphone, String auaddr, String autype);

	List<Adduser> find();

	Adduser findByNameAndAddr(String auname, String auaddr);

}
