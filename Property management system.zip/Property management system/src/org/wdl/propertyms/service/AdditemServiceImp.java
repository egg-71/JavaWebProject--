package org.wdl.propertyms.service;


import java.util.List;

import org.wdl.propertyms.bean.Additem;
import org.wdl.propertyms.dao.AdditemDao;
import org.wdl.propertyms.dao.AdditemDaoImpl;


public class AdditemServiceImp implements AdditemService {
	private AdditemDao additemDao=new AdditemDaoImpl();

	@Override
	public Additem insertItem(String feename, String manager, String price, String more, String feetype) {
		// TODO Auto-generated method stub
		return additemDao.inserItem(feename, manager, price, more, feetype);
	}

	@Override
	public List<Additem> find() {
		// TODO Auto-generated method stub
		return additemDao.find();
	}

	@Override
	public Additem removeItem(Integer id) {
		// TODO Auto-generated method stub
		return additemDao.removeItem(id);
	}



}
